<?php

namespace App\Repositories;

abstract class AbstractRepository
{

}