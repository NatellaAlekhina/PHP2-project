<?php

namespace App\Enums;

enum Date: string
{
    case DATETIME_FORMAT = 'Y-m-d H:i:s';
}