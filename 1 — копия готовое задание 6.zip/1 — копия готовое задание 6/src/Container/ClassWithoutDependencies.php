<?php

namespace App\Container;

class ClassWithoutDependencies
{

}