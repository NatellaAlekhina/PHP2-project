<?php

use \PHPUnit\Framework\TestCase;

class HelloTest extends TestCase
{
    public function testItWork(): void
    {
        $this->assertTrue(true);

    }
}